# Vefforritun 1, 2024: Verkefni 5, CSS #3 sýnilausn

Sýnilausn á [verkefni 5](https://github.com/vefforritun/vef1-2024-v5) byggð á sýnilausn á [verkefni 4](https://github.com/vefforritun/vef1-2024-v4-synilausn).
